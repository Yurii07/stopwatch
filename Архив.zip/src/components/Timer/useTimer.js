import { useState ,useEffect} from 'react';
import { debounce } from "lodash";
import { interval } from "rxjs";

import { Observable } from 'rxjs';
// RxJS v6+
import { timer } from 'rxjs';


const useTimer = (initialState = 0) => {
    const [timer, setTimer] = useState(initialState);
    const [interv, setInterv] = useState();
// хуйня для реактивного програмир
    const observable = new Observable(subscriber => {
        subscriber.next(1);
        subscriber.next(2);
        subscriber.next(3);
        setTimeout(() => {
            subscriber.next(4);
            subscriber.complete();
        }, 1000);
    });
    // console.log('just before subscribe');
    // observable.subscribe({
    //     next(x) { console.log('got value ' + x); },
    //     error(err) { console.error('something wrong occurred: ' + err); },
    //     complete() { console.log('done'); }
    // });
    // console.log('just after subscribe');
    // конец хуйни  для реактивного програмир


    const handleStart = () => {
        observable.subscribe({
            next(x) { console.log('got value ' + x); },
            error(err) { console.error('something wrong occurred: ' + err); },
            complete() { console.log('done'); }
        });
        setInterv(setInterval(run, 1000));
    };

    const run = () => {
        setTimer((timer) => timer + 1);
    };

    const handleStop = () => {
        clearInterval(interv);
        setInterv();
    };

    const handleReset = () => {
        clearInterval(interv);
        setTimer(0);
        handleStart();
    };

    const [isDoubleClick, setIsDoubleClick] = useState(false);
    const [waitReset] = useState(() => (debounce(() => {
            setIsDoubleClick(false);
        }, 300)
    ));

    const handleWait = () => {
        setIsDoubleClick(true);
        waitReset();
        if (isDoubleClick) {
            setIsDoubleClick(false);
            handleStop();
            console.log(' double click ');
        }
    };

    return { timer, interv, handleStart, handleStop, handleReset, handleWait }
}

export default useTimer