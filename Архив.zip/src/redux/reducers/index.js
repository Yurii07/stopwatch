import { combineReducers } from "redux";
import stopwatch from "./stopwatch";

const rootReducer = combineReducers({ stopwatch })

export default rootReducer;