import { START_TIMER } from "../actions/actionTypes";

const initialState = {
    // startedAt: undefined,
    // stoppedAt: undefined,
    // baseTime: undefined,
    counter: 0
};

const stopwatch = (state = initialState, { type, action }) => {
    switch (type) {
        // case START_TIMER:
        //     return state;

        default:
            return state;
    }
}

export default stopwatch;