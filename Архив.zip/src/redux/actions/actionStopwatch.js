export const startTimer = (id, text, isCompleted) => {
    return (dispatch, getState) => {
        console.log('reduxThunk state', getState());
        // const payload = { id, text, isCompleted }
        // dispatch(createAction(ADD_TASK, payload))
    }
}